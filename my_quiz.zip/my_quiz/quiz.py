import sys #The QUIT command in every raw_input
##Variables
easyQ_list = ["We live on planet BLANK", "My dad BLANK his car to work", "It is my BLANK every year", "Ssshhh the girl is going to BLANK in the school choir",
				"A monkey BLANK a tree"] #Easy Questions
medQ_list = ["10 + 10 = BLANK", "11 - 4 = BLANK", "3 x 4 = BLANK", "15 / 5 = BLANK", "8 + 18 = BLANK"] #Medium Questions
hardQ_list = ["BLANK is home to the Great Barrier Reef", "Nelson Mandela was born in BLANK", "The kiwi (bird) lives in BLANK",
				"BLANK is the capital city of England", "Antartica is at the BLANK pole"] #Hard Questions

easyA_list = ["EARTH", "DRIVES", "BIRTHDAY", "SING", "CLIMBS"] #Easy Answers
medA_list = [20, 7, 12, 3, 26] #Medium Answers
hardA_list = ["AUSTRALIA", "SOUTH AFRICA", "NEW ZEALAND", "LONDON", "SOUTH"] #Hard Answers

easyCl_list = [ ["mars", "orange", "earth", "moon"], ["is", "drives", "turns", "climbs"],
					["birthday", "christmas", "happy", "sad"], ["dances", "sing", "sits", "lemon"],
						["falls", "eat", "climbs", "banana"] ] #Easy Options for Answers
medCl_list = [ [100, 10, 21, 20], [11, 7, 4, 8], [3, 7, 4, 12], [20, 3, 4, 5], [20, 36, 26, 62] ] #Medium Options for Answers
hardCl_list = [ ["Sydney", "Australia", "New Zealand", "Thailand"], ["South Africa", "Asia", "India", "Ghana"],
					["Argentina", "Europe", "New Zealand", "Antartica"], ["Paris", "Ireland", "Manchester", "London"],
						["South", "West", "North", "East"] ] #Hard Options Answers
global level
level = 0
skipped = 2
scoreCard = [ [skipped, skipped, skipped, skipped, skipped], [skipped, skipped, skipped, skipped, skipped], [skipped, skipped, skipped, skipped, skipped] ] #0 = Incorrect & 1 = Correct
###############

def main (): #The main function that is executed to start the game
	print "Welcome to my Primary School Quiz \nMade by Jesse T\n"
	print "-- Type QUIT for any answer to exit the Quiz --\n"
	chooseLevel()
	printTotalScore()
	
def chooseLevel(): #The level is chosen, and each level is played, all functions are called here
	global level
	print "There are 3 levels: "
	nextStep = True
	while (nextStep):
		print "1) Easy: Simple English\n2) Medium: Basic Maths\n3) Hard: International Quiz\n"
		userInput = str(raw_input("Please choose a level number: ")) #Makes input uppercase for easier if statements
		quitGame(userInput)
		
		if userInput in ("1 2 3"):
			level = int(userInput)
			jumpStart()
			nextStep = False
		else:
			print "The level you chose does not exist!\n\nPlease enter the Number of the level you would like to play:"

def printAnswer(question, answer):#Inputs are the current question and the current correct answer - Prints out full sentence after user got it correct
	newAnswer = [ ]
	sentence = ""
	spot = 0
	while (spot < len(question)):
		if (question[spot] != "BLANK"):
			word = question[spot]
			newAnswer.append(word)
		else:
			word = str(answer)
			newAnswer.append(word)
		spot += 1
	sentence = " ".join(newAnswer)
	return sentence

def fillBlank(): #Raw input function with different questions, returning the user's Input
		global level
		userInput = ""
		if (level == 1 or level == 3):
			userInput = "" + str(raw_input("Fill in the blank: "))
		elif (level == 2):
			userInput = "" + str(raw_input("Complete the sum: "))
		return userInput

def whichQuestion(index): #Input of the current question number, output the question list string
		global level
		question = ""
		if (level == 1):
			question = easyQ_list[index].split()
		elif (level == 2):
			question = medQ_list[index].split()
		elif (level == 3):
			question = hardQ_list[index].split()
		return question
	
	
	
def whichLength(index): #Input the current question number, output the length of the answer
		global level
		lenAnswer = 0
		if (level == 1):
			lenAnswer = easyA_list[index]
		elif (level == 2):
			lenAnswer = medA_list[index]
		elif (level == 3):
			lenAnswer = hardA_list[index]
		return lenAnswer

def whichNewLife(index, question, lenAnswer): #Input the current question number, carries out the new seperate new life - 2nd multiple choice question - 
		global level
		if (level == 1 or level == 2):
			wordNewLife(index, printAnswer(question, lenAnswer))
		elif (level == 3):
			numNewLife(index, printAnswer(question, lenAnswer))

def playGame(): #It has no inputs but has other functions nested inside that have outputs. All the questions are displayed, answered and marked
	global level
	index = 0
	num_questions = len(easyQ_list)
	while (index < num_questions):
		question = whichQuestion(index)
		lenAnswer = whichLength(index)
		printBlank(question, lenAnswer)
		
		userInput = "" + fillBlank()
		print ""
		quitGame(userInput)
		
		if (markAnswer(userInput, index)): #Answer given is Correct
			index += 1
			print "That's Correct!\n->  " + printAnswer(question, lenAnswer) + "\n"
		else: #incorrect answer, 2nd chance given
			print "You gave the incorrect answer :(\nBut we will give you another chance ;)\n"
			printBlank(question, lenAnswer)
			printSecondChance(index)
			whichNewLife(index, question, lenAnswer)
			index += 1
	
	
	
def wordNewLife (index, question): #The inputs are the current index of the list of 5 questions and the current question string. Outputs the 2nd chance given to the user.
	userInput = raw_input("Fill in the blank, by entering the correct number: ")
	invalid = 4
	quitGame(userInput)
	if (tryInput2(userInput)):
		userInput2 = int(userInput)
	if (userInput2 > invalid):
		userInput2 = 1
	if (markAnswer2(userInput2, index)): #Answer given is Correct
		print "That's Correct!\n->  " + question + "\n"
	else:
		print "You gave the incorrect answer :(\n"

def numNewLife (index, question): #The inputs are the current index of the list of 5 questions and the current question string. Outputs the 2nd chance given to the user.
	userInput = raw_input("Complete the sum, by entering the correct number (1-4): ")
	quitGame(userInput)
	if (tryInput2(userInput)):
		userInput2 = int(userInput)

	if (markAnswer2(userInput2, index)): #Answer given is Correct
		print "That's Correct!\n->  " + question + "\n"
	else:
		print "That's incorrect :(\n"
		
		
		
def jumpStart(): #The level chosen first is played and if another is chosen then the following level is executed until completion
	global level
	nextLevel = ""
	lenTitle = 2
	while (level <= 3):
		if (level == 1):
			lenTitle = 21
			print "\nEasy: Simple English\n" + "-"*lenTitle
			playGame()
			printScoreCard(level)
		elif (level == 2):
			lenTitle = 19
			print "\nMedium: Basic Maths\n" + "-"*lenTitle
			playGame()
			printScoreCard(level)
		elif (level == 3):
			lenTitle = 24
			print "\nHard: International Quiz\n" + "-"*lenTitle
			playGame()
			break
		nextLevel = raw_input("Do you want to play the next level? (y) or (n)")
		quitGame(nextLevel)
		anotherOne(nextLevel)
		
		
def anotherOne(nextLevel): #Input yes or no answer to another level, function to increment the level value by 1 or end the game
	global level
	if (nextLevel.upper() == 'Y'):
		level += 1
	else:
		level = 4
		
	
	
	
def printTotalScore(): #Displays the total score from all levels
	correct = 0
	total = 0
	lenTitle = 12
	skipLevel = 10
	print "Your Results\n" + '*'*lenTitle
	for index in range(len(scoreCard)):
		if (sum(scoreCard[index]) == skipLevel):
			print "Level " + str(index+1) + ": Skipped"
		else:
			print "Level " + str(index+1) + ": " + str(sum(scoreCard[index])) + "/5"
			correct += sum(scoreCard[index])
			total += 5
	print '*'*lenTitle + "\nTotal Score: " + str(correct) + "/" + str(total)
	print "\nWell Done!\nThank you for playing the game\nGoodbye :)"

def printScoreCard(levelNum): #Displays the score out of 5 of the current level
	congrats = "Well Done! You finished level " + str(levelNum)
	print congrats + '\n' + '*'*len(congrats)
	sum = 0
	var = 0
	questions = 5
	while(var < questions):
		if (scoreCard[levelNum-1][var] == 1):
			sum += 1
		var += 1
	print "Your score was " + str(sum) + "/5."
	passQuiz = 3
	if (sum < passQuiz):
		print "Sorry, but you need to get 50% or more to pass the level.\nGo back and Study a bit more and then try again :)"
		print "Goodbye and Goodluck!"
		sys.exit()

def printBlank(question, lenAnswer):#Prints out Statement with ___ instead of BLANK
	newQuestion = []
	sentence = ""
	spot = 0
	while (spot < len(question)):
		if (question[spot] != "BLANK"):
			word = question[spot]
			newQuestion.append(word)
		else:
			try:
				word = "_"*len(lenAnswer)
			except TypeError:
				word = "?"
				newQuestion.append(word)
			else:
				word = "_"*len(lenAnswer)
				newQuestion.append(word)
		spot += 1
	sentence = " ".join(newQuestion)
	print sentence
	
	
def markAnswer(userInput, index): #Checks to see if the answer is correct
	global level
	if (level == 1):
		if (userInput.upper() == easyA_list[index]):
			scoreCard[0][index] = 1
			return True
		else:
			return False
	elif (level == 2):
		if (int(userInput) == medA_list[index]):
			scoreCard[1][index] = 1
			return True
		else:
			return False
	else:
		if (userInput.upper() == hardA_list[index]):
			scoreCard[2][index] = 1
			return True
		else:
			return False

def markAnswer2(userInput2, index): #Checks to see if the 2nd answer is correct after the multiple options given
	global level
	if (level == 1):
		if (easyCl_list[index][userInput2-1].upper() == easyA_list[index]):
			scoreCard[0][index] = 1
			return True
		else:
			scoreCard[0][index] = 0
			return False
	elif (level == 2):
		if (medCl_list[index][userInput2-1] == medA_list[index]):
			scoreCard[1][index] = 1
			return True
		else:
			scoreCard[1][index] = 0
			return False
	else:
		if (hardCl_list[index][userInput2-1].upper() == hardA_list[index]):
			scoreCard[2][index] = 1
			return True
		else:
			scoreCard[2][index] = 0
			return False

def printSecondChance (index): #Displays the 4 options as answers depending on current level
	global level
	indexVar = 0
	while (indexVar < len(easyCl_list[index])):
		if (level == 1):
			print "" + str(indexVar+1) + ') ' + easyCl_list[index][indexVar]
			indexVar += 1
		elif (level == 2):
			print "" + str(indexVar+1) + ') ' + str(medCl_list[index][indexVar])
			indexVar += 1
		else:
			print "" + str(indexVar+1) + ') ' + hardCl_list[index][indexVar]
			indexVar += 1

def quitGame(quit): #At any point if QUIT is entered the program exits
	if (quit.upper() == "QUIT"):
		print "You have exited the Quiz, Goodbye :)"
		sys.exit()
def tryInput2(userInput): #Checks to see if the user inputs a integer instead of a string and prevents the program from crashing
	try:
		userInput2 = int(userInput)
	except Exception:
		print "Invalid Answer!\nPlease read Question carefully, and Restart Game."
		sys.exit()
	else:
		return True
###MAIN###
main() #Executes the program