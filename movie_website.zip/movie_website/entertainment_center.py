import media
import fresh_tomatos

toy_story = media.Movie("Toy Story",
                          "A story of a boy and his toys come to life",
                            "https://upload.wikimedia.org/wikipedia/en/1/13/Toy_Story.jpg",
                              "https://www.youtube.com/watch?v=KYz2wyBy3kc")

avatar = media.Movie("Avatar",
                        "A marine on an alien planet",
                          "https://upload.wikimedia.org/wikipedia/en/b/b0/Avatar-Teaser-Poster.jpg",
                            "https://www.youtube.com/watch?v=5PSNL1qE6VY")

school_of_rock = media.Movie("School of Rock",
                              "Using rock music to learn",
                                "https://upload.wikimedia.org/wikipedia/en/1/11/School_of_Rock_Poster.jpg",
                                  "https://www.youtube.com/watch?v=XCwy6lW5Ixc")

ratatouille = media.Movie("Ratatouille",
                            "A rat who is a chef in Paris",
                              "https://upload.wikimedia.org/wikipedia/en/5/50/RatatouillePoster.jpg",
                                "https://www.youtube.com/watch?v=c3sBBRxDAqk")

midnight_in_paris = media.Movie("Midnight in Paris",
                                  "Going back in time to meet authors",
                                    "http://static.rogerebert.com/uploads/movie/movie_poster/midnight-in-paris-2011/large_xxSopLYATHXSepXcEaBh9Gazv6p.jpg",
                                      "https://www.youtube.com/watch?v=BYRWfS2s2v4")

jason_bourne = media.Movie("Jason Bourne",
                              "You know his name and what he can do",
                                "https://upload.wikimedia.org/wikipedia/en/b/b2/Jason_Bourne_%28film%29.jpg",
                                  "https://www.youtube.com/watch?v=F4gJsKZvqE4")

movies = [toy_story, avatar, school_of_rock, ratatouille, midnight_in_paris, jason_bourne] #Creates a list of the movie objects
fresh_tomatos.open_movies_page(movies) #Executes the open_movies_page function found in the fresh_tomatoes file that is imported
