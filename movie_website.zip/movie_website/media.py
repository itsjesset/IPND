import webbrowser

class Movie:
  """A Movie with a title, short description, Poster Image and video trailer"""
  def __init__(self, movie_title, storyline, poster_image, trailer_youtube): #Initialises the instance variables and creates the class object
    self.title = movie_title
    self.storyline = storyline
    self.poster_image_url = poster_image
    self.trailer_youtube_url = trailer_youtube
    
  def show_trailer(self): #Opens a new window to display the movies trailer
  """Displays the movie trailer of Class Movie in a new window"""
    webbrowser.open(self.trailer_youtube_url)
